from .models import GameLobby
# Create your views here.
from django.shortcuts import render, redirect
from .models import User, Lobby, ChatMessage
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from .models import Player
from .models import Score

def home(request):
    users = User.objects.all()
    lobbies = Lobby.objects.all()
    return render(request, 'lobby/home.html')

def join_game(request):
    if request.method == 'POST':
        game_code = request.POST.get('game_code')
        username = request.POST.get('username')

        try:
            lobby = GameLobby.objects.get(game_code=game_code)
            # Redirect to the snake game with the provided username
            return redirect('snake_game', username=username, game_code=game_code)
        except GameLobby.DoesNotExist:
            # Lobby doesn't exist
            return render(request, 'lobby/join_game.html', {
                'error': f'No lobby found with game code: {game_code}'
            })

    return render(request, 'lobby/join_game.html')

def create_game(request):
    if request.method == 'POST':
        game_name = request.POST.get('game_name')
        host_name = request.POST.get('host_name')
        is_private = request.POST.get('is_private') == 'on'  # Checkbox value

        # Generate a random game code
        import random, string
        game_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=6))

        # Create and save the lobby
        lobby = GameLobby.objects.create(
            game_code=game_code,
            game_name=game_name,
            host_name=host_name,
            is_private=is_private
        )

        # Redirect based on privacy setting
        if is_private:
            # For private lobbies, show the game code to the creator
            return render(request, 'lobby/lobby_created.html', {
                'lobby': lobby,
                'message': 'Private lobby created! Share this game code with players:'
            })
        else:
            return redirect('all_lobbies')  # Redirect to see the lobby list

    return render(request, 'lobby/create_game.html')

def leaderboard(request):
    # Global leaderboard showing all scores with lobby information
    scores = Score.objects.select_related().order_by('-score')[:10]  # Top 10
    # Add lobby information to each score
    for score in scores:
        try:
            score.lobby = GameLobby.objects.get(game_code=score.game_code)
        except GameLobby.DoesNotExist:
            score.lobby = None
    return render(request, 'lobby/leaderboard.html', {'leaderboard': scores, 'is_global': True})

def lobby_leaderboard(request, game_code):
    # Lobby-specific leaderboard
    try:
        lobby = GameLobby.objects.get(game_code=game_code)
        scores = Score.objects.filter(game_code=game_code).order_by('-score')[:10]  # Top 10 for this lobby
        return render(request, 'lobby/leaderboard.html', {
            'leaderboard': scores,
            'lobby': lobby,
            'is_global': False
        })
    except GameLobby.DoesNotExist:
        return redirect('leaderboard')  # Redirect to global leaderboard if lobby doesn't exist

def all_lobbies(request):
    # Show only public lobbies using the model method
    try:
        lobbies = GameLobby.get_public_lobbies()
        return render(request, 'lobby/all_lobbies.html', {'lobbies': lobbies})
    except Exception as e:
        # If there's still an error, return empty list
        return render(request, 'lobby/all_lobbies.html', {'lobbies': [], 'error': str(e)})

def snake_game(request, username, game_code):
    return render(request, 'lobby/snake_game.html', {
        'username': username,
        'game_code': game_code,
    })
    
def submit_score(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        game_code = request.POST.get('game_code')
        score = int(request.POST.get('score'))

        # Update or create a new score
        obj, created = Score.objects.update_or_create(
            username=username,
            game_code=game_code,
            defaults={'score': score}
        )

        # If score exists but new one is higher, update it
        if not created and score > obj.score:
            obj.score = score
            obj.save()

        return JsonResponse({'status': 'success'})
    return JsonResponse({'status': 'fail', 'reason': 'Invalid request'}, status=400)