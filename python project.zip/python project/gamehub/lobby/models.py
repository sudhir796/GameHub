from django.db import models

# Create your models here.

class User(models.Model):
    id = models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
    username = models.CharField(max_length=50, unique=True)

class Lobby(models.Model):
    id = models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
    name = models.CharField(max_length=100)
    creator = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_lobbies')
    players = models.ManyToManyField(User, related_name='joined_lobbies')
    max_players = models.IntegerField(default=4)

class ChatMessage(models.Model):
    id = models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    lobby = models.ForeignKey(Lobby, on_delete=models.CASCADE)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

class GameLobby(models.Model):
    id = models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
    game_code = models.CharField(max_length=10, unique=True)
    game_name = models.CharField(max_length=100)
    host_name = models.CharField(max_length=100)
    is_private = models.BooleanField(default=False, help_text="Private lobbies are not visible in public lobby list")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        privacy_status = "Private" if self.get_is_private() else "Public"
        return f"{self.game_name} ({self.game_code}) - {privacy_status}"

    def get_is_private(self):
        """Safely get the is_private value"""
        return getattr(self, 'is_private', False)

    @classmethod
    def get_public_lobbies(cls):
        """Get all public lobbies using Python filtering to avoid Djongo issues"""
        all_lobbies = cls.objects.all().order_by('-created_at')
        return [lobby for lobby in all_lobbies if not lobby.get_is_private()]

class Player(models.Model):
    id = models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
    username = models.CharField(max_length=100)
    game_code = models.CharField(max_length=10)
    score = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.username} ({self.game_code}) - {self.score}"

class Score(models.Model):
    id = models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')
    username = models.CharField(max_length=100)
    game_code = models.CharField(max_length=10)
    score = models.IntegerField(default=0)

    def __str__(self):
        return f"{self.username} - {self.score}"