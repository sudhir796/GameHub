from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('join/', views.join_game, name='join_game'),
    path('create/', views.create_game, name='create_game'),
    path('leaderboard/', views.leaderboard, name='leaderboard'),
    path('leaderboard/<str:game_code>/', views.lobby_leaderboard, name='lobby_leaderboard'),
    path('lobbies/', views.all_lobbies, name='all_lobbies'),
    path('play/<str:username>/<str:game_code>/', views.snake_game, name='snake_game'),
    path('submit-score/', views.submit_score, name='submit_score'),
]
