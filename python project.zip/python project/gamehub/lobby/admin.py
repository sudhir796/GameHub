from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import User, Lobby, ChatMessage, GameLobby, Player, Score

@admin.register(GameLobby)
class GameLobbyAdmin(admin.ModelAdmin):
    list_display = ['game_code', 'game_name', 'host_name', 'is_private', 'created_at']
    list_filter = ['is_private', 'created_at']
    search_fields = ['game_code', 'game_name', 'host_name']
    readonly_fields = ['created_at']

@admin.register(Score)
class ScoreAdmin(admin.ModelAdmin):
    list_display = ['username', 'game_code', 'score']
    list_filter = ['game_code']
    search_fields = ['username', 'game_code']

admin.site.register(User)
admin.site.register(Lobby)
admin.site.register(ChatMessage)
admin.site.register(Player)
