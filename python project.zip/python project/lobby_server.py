import socket
import threading
import json
from queue import Queue

class LobbyServer:
    def __init__(self, host='0.0.0.0', port=5555):
        self.host = host
        self.port = port
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.bind((host, port))
        self.server.listen()
        
        self.lobbies = {}  # {lobby_id: {'players': [], 'settings': {}}}
        self.players = {}  # {client: {'name': '', 'lobby': None}}
        self.message_queue = Queue()
        self.lobby_id_counter = 1
        
        print(f"Server started on {host}:{port}")

    def broadcast(self, message, lobby_id, exclude_client=None):
        """Send message to all players in a lobby"""
        if lobby_id not in self.lobbies:
            return
            
        for client in self.lobbies[lobby_id]['players']:
            if client != exclude_client:
                try:
                    client.send(message.encode('utf-8'))
                except:
                    self.handle_disconnect(client)

    def handle_client(self, client):
        """Handle individual client connections"""
        while True:
            try:
                message = client.recv(1024).decode('utf-8')
                if not message:
                    break
                    
                data = json.loads(message)
                self.process_message(client, data)
                
            except (ConnectionResetError, json.JSONDecodeError):
                self.handle_disconnect(client)
                break

    def process_message(self, client, data):
        """Process incoming messages from clients"""
        action = data.get('action')
        
        if action == 'join':
            self.players[client] = {'name': data['name'], 'lobby': None}
            client.send(json.dumps({
                'status': 'success',
                'message': f"Welcome {data['name']}! Use /create or /join [lobby_id]"
            }).encode('utf-8'))
            
        elif action == 'create':
            lobby_id = self.lobby_id_counter
            self.lobby_id_counter += 1
            
            self.lobbies[lobby_id] = {
                'players': [client],
                'settings': data.get('settings', {}),
                'ready_players': set()
            }
            
            self.players[client]['lobby'] = lobby_id
            
            client.send(json.dumps({
                'status': 'success',
                'message': f"Lobby {lobby_id} created!",
                'lobby_id': lobby_id
            }).encode('utf-8'))
            
        elif action == 'join_lobby':
            lobby_id = data['lobby_id']
            
            if lobby_id not in self.lobbies:
                client.send(json.dumps({
                    'status': 'error',
                    'message': f"Lobby {lobby_id} doesn't exist"
                }).encode('utf-8'))
                return
                
            if len(self.lobbies[lobby_id]['players']) >= self.lobbies[lobby_id]['settings'].get('max_players', 4):
                client.send(json.dumps({
                    'status': 'error',
                    'message': f"Lobby {lobby_id} is full"
                }).encode('utf-8'))
                return
                
            self.lobbies[lobby_id]['players'].append(client)
            self.players[client]['lobby'] = lobby_id
            
            join_message = f"{self.players[client]['name']} joined the lobby"
            self.broadcast(json.dumps({
                'action': 'chat',
                'message': join_message
            }), lobby_id)
            
        elif action == 'chat':
            lobby_id = self.players[client]['lobby']
            if lobby_id:
                message = f"{self.players[client]['name']}: {data['message']}"
                self.broadcast(json.dumps({
                    'action': 'chat',
                    'message': message
                }), lobby_id)
                
        elif action == 'ready':
            lobby_id = self.players[client]['lobby']
            if lobby_id:
                self.lobbies[lobby_id]['ready_players'].add(client)
                ready_count = len(self.lobbies[lobby_id]['ready_players'])
                total_players = len(self.lobbies[lobby_id]['players'])
                
                self.broadcast(json.dumps({
                    'action': 'status',
                    'message': f"{self.players[client]['name']} is ready ({ready_count}/{total_players})"
                }), lobby_id)
                
                if ready_count == total_players and total_players > 1:
                    self.broadcast(json.dumps({
                        'action': 'start_game',
                        'message': "All players ready! Starting game..."
                    }), lobby_id)

    def handle_disconnect(self, client):
        """Handle client disconnection"""
        if client in self.players:
            player_name = self.players[client]['name']
            lobby_id = self.players[client]['lobby']
            
            if lobby_id and lobby_id in self.lobbies:
                self.lobbies[lobby_id]['players'].remove(client)
                if client in self.lobbies[lobby_id]['ready_players']:
                    self.lobbies[lobby_id]['ready_players'].remove(client)
                    
                leave_message = f"{player_name} left the lobby"
                self.broadcast(json.dumps({
                    'action': 'chat',
                    'message': leave_message
                }), lobby_id, client)
                
                if len(self.lobbies[lobby_id]['players']) == 0:
                    del self.lobbies[lobby_id]
            
            del self.players[client]
            client.close()

    def start(self):
        """Start the server and accept connections"""
        while True:
            client, address = self.server.accept()
            print(f"New connection from {address}")
            
            thread = threading.Thread(target=self.handle_client, args=(client,))
            thread.start()

if __name__ == "__main__":
    server = LobbyServer()
    server.start()