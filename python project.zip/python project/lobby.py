MAX_USERS = 10
MAX_LOBBIES = 5
MAX_PLAYERS = 4

class User:
    def __init__(self, username):
        self.username = username

class Chat:
    def __init__(self):
        self.messages = []

    def post_message(self, user, msg):
        message = user + ": " + msg
        self.messages.append(message)

    def show_messages(self):
        print("\n--- Chat Messages ---")
        for msg in self.messages:
            print(msg)
        print("---------------------")

class Lobby:
    def __init__(self, name, creator):
        self.lobby_name = name
        self.players = [creator]
        self.chat = Chat()

    def join_lobby(self, player):
        if len(self.players) < MAX_PLAYERS:
            self.players.append(player)
            return True
        else:
            return False

    def show_lobby(self):
        print("\nLobby:", self.lobby_name)
        print("Players:")
        for p in self.players:
            print("-", p.username)
        self.chat.show_messages()

users = []
lobbies = []

def register():
    name = input("Enter your username: ")
    user = User(name)
    users.append(user)
    print("Welcome,", name)
    return user

def create_lobby(user):
    name = input("Enter lobby name: ")
    lobby = Lobby(name, user)
    lobbies.append(lobby)
    print("Lobby created.")

def join_lobby(user):
    if len(lobbies) == 0:
        print("No lobbies available.")
        return
    print("Available lobbies:")
    for i in range(len(lobbies)):
        print(i + 1, lobbies[i].lobby_name)
    choice = int(input("Choose a lobby to join: ")) - 1
    if 0 <= choice < len(lobbies):
        lobby = lobbies[choice]
        if lobby.join_lobby(user):
            print("Joined the lobby.")
            chat_loop(lobby, user)
        else:
            print("Lobby is full.")

def chat_loop(lobby, user):
    while True:
        lobby.show_lobby()
        msg = input("Enter message (or 'exit' to leave): ")
        if msg.lower() == 'exit':
            break
        lobby.chat.post_message(user.username, msg)

def main():
    print("Welcome to GameHub!")
    current_user = register()
    while True:
        print("\n1. Create Lobby\n2. Join Lobby\n3. Quit")
        choice = input("Choose an option: ")
        if choice == '1':
            create_lobby(current_user)
        elif choice == '2':
            join_lobby(current_user)
        elif choice == '3':
            print("Goodbye!")
            break
        else:
            print("Invalid choice.")

if __name__ == "__main__":
    main()
