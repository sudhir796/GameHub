import socket
import json
import threading
import time

class LobbyClient:
    def __init__(self, host='127.0.0.1', port=5555):
        self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.host = host
        self.port = port
        self.name = ""
        self.connected = False
        
    def connect(self, name):
        """Connect to the server with a player name"""
        try:
            self.client.connect((self.host, self.port))
            self.name = name
            self.connected = True
            
            # Send join message
            self.send_message({'action': 'join', 'name': name})
            
            # Start thread to listen for messages
            receive_thread = threading.Thread(target=self.receive_messages)
            receive_thread.daemon = True
            receive_thread.start()
            
            return True
        except:
            return False
            
    def send_message(self, data):
        """Send a message to the server"""
        try:
            self.client.send(json.dumps(data).encode('utf-8'))
            return True
        except:
            self.connected = False
            return False
            
    def receive_messages(self):
        """Receive messages from server"""
        while self.connected:
            try:
                message = self.client.recv(1024).decode('utf-8')
                if not message:
                    self.connected = False
                    break
                    
                data = json.loads(message)
                self.handle_message(data)
                
            except:
                self.connected = False
                break
                
    def handle_message(self, data):
        """Handle incoming messages from server"""
        if data.get('action') == 'chat':
            print(data['message'])
        elif data.get('action') == 'status':
            print(f"[STATUS] {data['message']}")
        elif data.get('action') == 'start_game':
            print(f"[GAME] {data['message']}")
            # Here you would typically transition to the actual game
        else:
            print(f"[SERVER] {data.get('message', 'Unknown message')}")

    def create_lobby(self, max_players=4, game_mode="deathmatch"):
        """Create a new lobby"""
        return self.send_message({
            'action': 'create',
            'settings': {
                'max_players': max_players,
                'game_mode': game_mode
            }
        })
        
    def join_lobby(self, lobby_id):
        """Join an existing lobby"""
        return self.send_message({
            'action': 'join_lobby',
            'lobby_id': lobby_id
        })
        
    def send_chat(self, message):
        """Send chat message to lobby"""
        return self.send_message({
            'action': 'chat',
            'message': message
        })
        
    def set_ready(self):
        """Mark player as ready"""
        return self.send_message({
            'action': 'ready'
        })

def main():
    name = input("Enter your name: ")
    client = LobbyClient()
    
    if not client.connect(name):
        print("Failed to connect to server")
        return
        
    print("Connected to server. Commands:")
    print("/create - Create a new lobby")
    print("/join [id] - Join a lobby")
    print("/ready - Mark yourself as ready")
    print("/quit - Exit")
    
    while client.connected:
        message = input()
        
        if message.lower() == '/quit':
            client.connected = False
            client.client.close()
            break
            
        elif message.lower() == '/create':
            if client.create_lobby():
                print("Lobby creation requested")
            else:
                print("Failed to send lobby creation request")
                
        elif message.lower().startswith('/join '):
            try:
                lobby_id = int(message.split()[1])
                if client.join_lobby(lobby_id):
                    print(f"Requested to join lobby {lobby_id}")
                else:
                    print("Failed to send join request")
            except (IndexError, ValueError):
                print("Invalid lobby ID")
                
        elif message.lower() == '/ready':
            if client.set_ready():
                print("Ready status sent")
            else:
                print("Failed to send ready status")
                
        else:
            if client.send_chat(message):
                pass  # Message will be echoed back from server
            else:
                print("Failed to send message")

if __name__ == "__main__":
    main()